import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 c=b.new_context(viewport={'width':320,'height':680},is_mobile=True,has_touch=True)
 page=c.new_page();results=[]
 for route,title in [('/merge-pdf','Select PDF files'),('/compress-pdf','Select one PDF file'),('/jpg-to-pdf','Select image files')]:
  page.goto('http://127.0.0.1:3003'+route);page.evaluate('document.fonts.ready')
  group=page.get_by_role('group',name=title,exact=True)
  results.append({'route':route,'details':group.evaluate('''el=>{
   const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');canvas.width=canvas.height=1;
   function rgb(color){ctx.clearRect(0,0,1,1);ctx.fillStyle=color;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data].slice(0,3);}
   const bg=rgb(getComputedStyle(el).backgroundColor);
   function lum(v){return v.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4}).reduce((s,x,i)=>s+x*[.2126,.7152,.0722][i],0)}
   return [...el.querySelectorAll('p')].map(p=>{
    const s=getComputedStyle(p),r=p.getBoundingClientRect(),fg=rgb(s.color),a=lum(fg),b=lum(bg);
    return {text:p.textContent,fontSize:s.fontSize,color:s.color,background:getComputedStyle(el).backgroundColor,contrast:(Math.max(a,b)+.05)/(Math.min(a,b)+.05),top:r.top,bottom:r.bottom,visibleWithinViewport:r.top>=0&&r.bottom<=innerHeight};
   });
  }''')})
 (root/'readability.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2));b.close()
