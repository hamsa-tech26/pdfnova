import base from '/workspace/pdfnova/playwright.config.mjs';
export default {...base,testDir:'/workspace/pdfnova/e2e',outputDir:'/workspace/work/mobile-entry-20261027/browser-results',webServer:undefined,retries:0,use:{...base.use,baseURL:'http://127.0.0.1:3003',launchOptions:{executablePath:'/usr/bin/chromium',args:['--no-sandbox']}}};
