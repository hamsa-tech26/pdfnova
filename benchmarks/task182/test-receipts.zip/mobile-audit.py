from pathlib import Path
import json,re,time,hashlib
import fitz
from PIL import Image
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
inputs=root/'inputs';inputs.mkdir(exist_ok=True)
for n in [1,2]:
 d=fitz.open();p=d.new_page();p.insert_text((50,70),'AUDIT_ONLY_SYNTHETIC_DOCUMENT_20261027 '+str(n));d.save(inputs/('control-'+str(n)+'.pdf'))
 Image.new('RGB',(320,240),(n*70,90,140)).save(inputs/('image-'+str(n)+'.png'))
base='http://127.0.0.1:3003'
paths=['/','/merge-pdf','/compress-pdf','/jpg-to-pdf']
labels={'/':'Open Kukureku PDF Tools','/merge-pdf':'Choose PDF Files','/compress-pdf':'Choose PDF File','/jpg-to-pdf':'Choose Images'}
result={'scope':'LOCAL_PRODUCTION_BUILD_OF_LIVE_COMMIT_NOT_PHYSICAL_DEVICE_OR_LIVE_CWV','commit':'WORKING_MOBILE_DRAFT','screens':[],'flows':[],'metadata':[]}
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(320,680),(390,844),(768,1024),(1440,900)]:
  c=b.new_context(viewport={'width':width,'height':height},is_mobile=width<768,has_touch=width<768,accept_downloads=True)
  page=c.new_page();page.route('**/_vercel/insights/**',lambda r:r.fulfill(status=204,body=''))
  for path in paths:
   response=page.goto(base+path);page.evaluate('document.fonts.ready');page.wait_for_timeout(250)
   loc=page.get_by_role('link' if path=='/' else 'button',name=labels[path],exact=True)
   box=loc.bounding_box()
   data={'path':path,'width':width,'height':height,'status':response.status,'primaryAction':labels[path],'actionBox':box,'fullyInFirstViewport':box['y']>=0 and box['y']+box['height']<=height,'horizontalOverflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')}
   if path=='/':
    tool=page.locator('main a[href="/merge-pdf"]').first;data['firstDirectMergeLinkBox']=tool.bounding_box();data['primaryHref']=loc.get_attribute('href')
   result['screens'].append(data)
   if width==390:
    page.screenshot(path=str(root/('mobile-'+(path.strip('/') or 'home')+'.png')))
   if width==1440:
    result['metadata'].append({'path':path,'title':page.title(),'description':page.locator('meta[name=description]').get_attribute('content'),'canonical':page.locator('link[rel=canonical]').get_attribute('href'),'h1s':page.locator('h1').all_text_contents(),'robots':page.locator('meta[name=robots]').all_text_contents(),'schemas':page.locator('script[type="application/ld+json"]').count()})
  c.close()
 c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 page=c.new_page();page.route('**/_vercel/insights/**',lambda r:r.fulfill(status=204,body=''))
 requests=[]
 def on_request(req):
  body=req.post_data_buffer
  if body:requests.append({'method':req.method,'bytes':len(body),'containsSyntheticCanary':b'AUDIT_ONLY_SYNTHETIC_DOCUMENT_20261027' in body})
 page.on('request',on_request)
 for path,button,files in [('/merge-pdf','Merge and Download PDF',[inputs/'control-1.pdf',inputs/'control-2.pdf']),('/compress-pdf','Compress and Download PDF',[inputs/'control-1.pdf']),('/jpg-to-pdf','Create and Download PDF',[inputs/'image-1.png',inputs/'image-2.png'])]:
  page.goto(base+path);page.locator('input[type=file]').set_input_files([str(p) for p in files])
  if path=='/compress-pdf':page.get_by_role('button',name='Low Better compatibility',exact=True).click()
  start=time.monotonic()
  with page.expect_download(timeout=60000) as download:
   page.get_by_role('button',name=re.compile('^'+button)).click()
  target=root/(path.strip('/')+'-download.pdf');download.value.save_as(target)
  with fitz.open(target) as doc:
   pages=len(doc);texts=[p.get_text() for p in doc]
   if path=='/merge-pdf':assert pages==2 and '20261027 1' in texts[0] and '20261027 2' in texts[1]
   if path=='/compress-pdf':assert pages==1 and 'AUDIT_ONLY_SYNTHETIC_DOCUMENT' in texts[0]
   if path=='/jpg-to-pdf':assert pages==2 and all(len(p.get_images())>0 for p in doc)
  result['flows'].append({'path':path,'downloadVerified':True,'pages':pages,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'secondsLocalOnly':time.monotonic()-start})
  page.screenshot(path=str(root/(path.strip('/')+'-success.png')))
 result['syntheticDocumentBodyRequests']=requests
 for p in ['/robots.txt','/sitemap.xml']:
  response=c.request.get(base+p);(root/(p.strip('/'))).write_text(response.text());result[p]={'status':response.status,'contentType':response.headers.get('content-type')}
 c.close();b.close()
(root/'mobile-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
