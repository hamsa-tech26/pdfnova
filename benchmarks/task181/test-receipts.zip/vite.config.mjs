import {defineConfig} from '/workspace/pdfnova/node_modules/vite/dist/node/index.js';
import {resolve} from 'node:path';
export default defineConfig({resolve:{alias:{'@':process.cwd()}},build:{outDir:'/workspace/work/task181/analysis-bundle',emptyOutDir:true,
  lib:{entry:resolve('/workspace/work/task181/analysis-entry.mjs'),formats:['es'],fileName:'analysis'},minify:false}});
