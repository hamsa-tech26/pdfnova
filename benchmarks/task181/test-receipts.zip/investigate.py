import json,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
sources=[root/'pdfplumber/examples/pdfs/background-checks.pdf',root/'pdfplumber/examples/pdfs/ag-energy-round-up-2017-02-24.pdf',root/'pdfplumber/tests/pdfs/issue-140-example.pdf',root/'camelot/tests/files/foo.pdf']
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page()
    page.route('**/__analysis/**',lambda r:r.fulfill(path=str(root/'analysis-bundle'/r.request.url.split('/')[-1]),content_type='text/javascript'))
    page.route('**/pdfjs-dist/**',lambda r:r.fulfill(path='node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs',content_type='text/javascript'))
    page.goto('http://127.0.0.1:3000/pdf-to-excel')
    page.add_script_tag(url='/__analysis/analysis.mjs',type='module')
    page.wait_for_function('typeof window.analyzeReference === "function"')
    results=[]
    for source in sources:
        data=source.read_bytes()
        r=page.evaluate('(bytes)=>window.analyzeReference(bytes)',list(data))
        r['possibleTableExperiment']=page.evaluate('(bytes)=>window.analyzeReference(bytes,true)',list(data))
        r.update(source=source.name,sha256=hashlib.sha256(data).hexdigest())
        downloads=[]
        page.on('download',lambda d:downloads.append(d.suggested_filename))
        page.locator('input[type=file]').set_input_files(str(source))
        page.get_by_role('button',name='Convert to Excel (.xlsx)').click()
        page.get_by_text('Excel conversion withheld',exact=True).wait_for()
        r['uiRefusal']=page.locator('body').inner_text().split('Excel conversion withheld')[-1][:700]
        r['downloads']=downloads
        results.append(r)
    (root/'real-refusals.json').write_text(json.dumps(results,indent=2))
    print(json.dumps([{'source':r['source'],'tables':r['tables'],'quality':r['quality'],'downloads':r['downloads']} for r in results]))
    browser.close()
