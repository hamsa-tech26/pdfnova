import base from './playwright.config.mjs';
export default {...base,testMatch:'**/real-table-refusals.pilot.mjs',outputDir:'/workspace/work/task181/refusal-results'};
