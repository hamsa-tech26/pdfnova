import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page()
 page.route('**/__analysis/**',lambda r:r.fulfill(path=str(root/'analysis-bundle'/r.request.url.split('/')[-1]),content_type='text/javascript'))
 page.route('**/pdfjs-dist/**',lambda r:r.fulfill(path='node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs' if 'min' in r.request.url else 'node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs',content_type='text/javascript'))
 page.goto('http://127.0.0.1:3000/redact-pdf')
 page.add_script_tag(url='/__analysis/analysis.mjs',type='module')
 page.wait_for_function('typeof window.cancelRedactionAt === "function"')
 results={}
 for stage in ['rendering','embedding','export']:
  result=page.evaluate('([bytes,stage])=>window.cancelRedactionAt(bytes,stage)',[list((root/'multipage.pdf').read_bytes()),stage])
  results[stage]=result
  assert result=={'status':'AbortError','reached':True,'liveCanvasPixels':0}, result
 (root/'stage-cancellation.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results))
 browser.close()
