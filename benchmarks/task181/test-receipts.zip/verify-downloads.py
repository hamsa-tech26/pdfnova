import json, math, hashlib
from pathlib import Path
import fitz, numpy as np
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
cases=[('final-trial1',root/'multipage.pdf'),('actual-fbi',root/'pdfplumber/examples/pdfs/background-checks.pdf'),('actual-usda',root/'pdfplumber/examples/pdfs/ag-energy-round-up-2017-02-24.pdf'),('derived-300dpi',root/'derived-300dpi.pdf')]
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page()
 page.route('**/__native.mjs',lambda r:r.fulfill(path='node_modules/pdfjs-dist/legacy/build/pdf.mjs',content_type='text/javascript'))
 page.route('**/__native-worker.mjs',lambda r:r.fulfill(path='node_modules/pdfjs-dist/legacy/build/pdf.worker.min.mjs',content_type='text/javascript'))
 page.goto('http://127.0.0.1:3000/redact-pdf')
 for label,source in cases:
  refs=page.evaluate('''async bytes=>{
    const lib=await import('/__native.mjs');lib.GlobalWorkerOptions.workerSrc='/__native-worker.mjs';
    const task=lib.getDocument({data:new Uint8Array(bytes)}),refs=[];
    try {const doc=await task.promise;for(let n=1;n<=doc.numPages;n++){
      const p=await doc.getPage(n),base=p.getViewport({scale:1});
      const v=p.getViewport({scale:Math.min(1.75,3200/Math.max(base.width,base.height))});
      const c=document.createElement('canvas');c.width=Math.ceil(v.width);c.height=Math.ceil(v.height);
      await p.render({canvas:c,canvasContext:c.getContext('2d'),viewport:v,background:'#FFFFFF'}).promise;
      refs.push({png:c.toDataURL('image/png').split(',')[1],width:base.width,height:base.height});
      c.width=c.height=0;p.cleanup();
    }return refs;}finally{await task.destroy();}
  }''',list(source.read_bytes()))
  import base64
  checked=selected=mismatches=0
  with fitz.open(root/(label+'-download.pdf')) as doc:
   assert len(doc)==len(refs)
   images=set()
   for i,(p,ref) in enumerate(zip(doc,refs)):
    assert not p.get_text() and not p.get_fonts() and not p.get_links() and not list(p.widgets() or []) and not list(p.annots() or [])
    assert len(p.get_images(full=True))==1
    xref=p.get_images(full=True)[0][0];images.add(xref)
    actual=fitz.Pixmap(doc,xref);reference=fitz.Pixmap(base64.b64decode(ref['png']))
    if reference.alpha:reference=fitz.Pixmap(reference,0)
    assert actual.n==reference.n==3
    assert (actual.width,actual.height)==(reference.width,reference.height)
    assert abs(p.rect.width-ref['width'])<.001 and abs(p.rect.height-ref['height'])<.001
    a=np.frombuffer(actual.samples,np.uint8).reshape(actual.height,actual.width,3)
    b=np.frombuffer(reference.samples,np.uint8).reshape(reference.height,reference.width,3)
    mask=np.zeros((actual.height,actual.width),dtype=bool)
    if i==0:mask[math.floor(.1*actual.height):math.ceil((.1+.2)*actual.height),math.floor(.1*actual.width):math.ceil((.1+.2)*actual.width)]=True
    selected+=int(mask.sum());checked+=mask.size
    mismatches+=int(np.any(a[mask]!=0,axis=1).sum())+int(np.any(a[~mask]!=b[~mask],axis=1).sum())
   assert doc.embfile_count()==0
   stored=set()
   for xref in range(1,doc.xref_length()):
    obj=doc.xref_object(xref,compressed=False)
    if '/Subtype /Image' in obj:stored.add(xref)
    assert '/Type /Font' not in obj and '/Subtype /Form' not in obj
   assert stored==images
  result=dict(case=label,pages=len(refs),checkedPixels=checked,selectedPixels=selected,mismatchedPixels=mismatches,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),outputSha256=hashlib.sha256((root/(label+'-download.pdf')).read_bytes()).hexdigest())
  assert mismatches==0,result
  results.append(result)
 browser.close()
(root/'download-verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
