import json,sys,time,threading
from pathlib import Path
import fitz, psutil
from playwright.sync_api import sync_playwright

root=Path(__file__).parent
source=Path(sys.argv[2]) if len(sys.argv)>2 else root/'multipage.pdf'
if not source.exists():
    doc=fitz.open()
    for n in range(6):
        p=doc.new_page(width=1000,height=1400)
        p.insert_text((50,80),'PUBLIC SYNTHETIC RESOURCE CONTROL '+str(n),fontsize=20)
        for y in range(100,1300,12):
            p.draw_line((40,y),(950,y),color=((y%17)/17,(y%31)/31,(y%47)/47))
    doc.save(source)
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(accept_downloads=True)
    page.add_init_script('''(() => {
      const canvases=new Set(), create=document.createElement.bind(document);
      document.createElement=function(...args){const el=create(...args);if(args[0]==='canvas')canvases.add(el);return el;};
      window.__samples=[];window.__gaps=[];let last=performance.now();
      setInterval(()=>{const now=performance.now();if(window.__measure)window.__gaps.push(now-last);last=now},10);
      const timer=window.setTimeout.bind(window);
      window.setTimeout=function(fn,delay,...args){return timer(()=>{
        if(window.__measure)window.__samples.push([...canvases].reduce((n,c)=>n+c.width*c.height*4,0));
        fn(...args);
      },delay)};
    })()''')
    page.goto('http://127.0.0.1:3000/redact-pdf')
    page.locator('input[type=file]').set_input_files(str(source))
    page.get_by_alt_text('PDF page 1 preview').wait_for()
    for label,value in [('Left %','10'),('Top %','10'),('Width %','20'),('Height %','20')]:
        page.get_by_role('group',name='Redaction area on page 1').get_by_label(label,exact=True).fill(value)
    page.get_by_role('button',name='Add redaction area',exact=True).click()
    page.evaluate('window.__measure=true')
    peaks=[]; stop=threading.Event()
    def sample():
        while not stop.wait(.02):
            try: peaks.append(sum(p.memory_info().rss for p in psutil.Process().children(recursive=True) if 'chrom' in p.name()))
            except psutil.Error: pass
    thread=threading.Thread(target=sample);thread.start();start=time.monotonic()
    try:
        with page.expect_download(timeout=180000) as d:
            page.get_by_role('button',name='Redact and Download PDF').click()
        d.value.save_as(str(root/(sys.argv[1]+'-download.pdf')))
    finally: stop.set();thread.join()
    elapsed=time.monotonic()-start
    metrics=page.evaluate('({maxGapMs:Math.max(...window.__gaps),canvasBytesAtTimers:window.__samples})')
    metrics.update(seconds=elapsed,peakBrowserRssBytes=max(peaks,default=0),outputBytes=(root/(sys.argv[1]+'-download.pdf')).stat().st_size)
    (root/(sys.argv[1]+'.json')).write_text(json.dumps(metrics,indent=2))
    print(json.dumps(metrics))
    browser.close()
