import {analyzePdfV4} from '/workspace/pdfnova/lib/pdf-engine-v4/pipeline/analyzePdfV4.ts';
import {preparePdfV4XlsxExport} from '/workspace/pdfnova/lib/converters/pdfToXlsxQuality.ts';
window.analyzeReference = async (bytes, includePossibleTableRegions = false) => {
  const result = await analyzePdfV4(new File([new Uint8Array(bytes)], 'reference.pdf', {type: 'application/pdf'}), {enableControlledOcr: false, includePossibleTableRegions});
  let quality;
  try {const plan=preparePdfV4XlsxExport(result); quality={accepted:true, tables:plan.tables.map(t=>({rows:t.rows.length,columns:t.rows[0]?.length}))};}
  catch(e) {quality={accepted:false,reason:e.message};}
  return {statistics:result.statistics, analysisOutcome:result.analysisOutcome,
    analyses:result.tableAnalyses.map(a=>({columns:a.columnDetection, rows:a.rowDetection, built:!!a.table})), diagnostics:result.candidateRegionDiagnostics,
    nativePages:result.nativePageTextExtraction, ocrDecision:result.ocrDecision,
    tables:result.tables.map(t=>({rows:t.rows.length,columns:t.columnCount,bounds:t.bounds})),quality};
};
import {createRasterRedactedPdf} from '/workspace/pdfnova/lib/pdf/redaction.ts';
import {PDFDocument} from '/workspace/pdfnova/node_modules/pdf-lib/es/index.js';
window.cancelRedactionAt = async (bytes, stage) => {
  const controller = new AbortController();
  const originalEmbed = PDFDocument.prototype.embedPng;
  const originalSave = PDFDocument.prototype.save;
  const originalContext = HTMLCanvasElement.prototype.getContext;
  const canvases = new Set();
  let reached = false;
  HTMLCanvasElement.prototype.getContext = function(...args) {
    canvases.add(this);
    if (stage === 'rendering' && !reached) {reached=true;setTimeout(()=>controller.abort(),0);}
    return originalContext.apply(this,args);
  };
  PDFDocument.prototype.embedPng = async function(...args) {
    const result=await originalEmbed.apply(this,args);
    if(stage==='embedding'){reached=true;controller.abort();}
    return result;
  };
  PDFDocument.prototype.save = async function(...args) {
    const result=await originalSave.apply(this,args);
    if(stage==='export'){reached=true;setTimeout(()=>controller.abort(),0);}
    return result;
  };
  try {
    await createRasterRedactedPdf(new File([new Uint8Array(bytes)],'control.pdf',{type:'application/pdf'}),
      {1:[{x:.1,y:.1,width:.2,height:.2}]},{signal:controller.signal});
    return {status:'UNEXPECTED_BYTES',reached};
  } catch(e) {return {status:e.name,reached,liveCanvasPixels:[...canvases].reduce((n,c)=>n+c.width*c.height,0)};}
  finally {
    HTMLCanvasElement.prototype.getContext=originalContext;
    PDFDocument.prototype.embedPng=originalEmbed;
    PDFDocument.prototype.save=originalSave;
  }
};
