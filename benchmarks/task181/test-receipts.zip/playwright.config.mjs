import base from '/workspace/pdfnova/playwright.config.mjs';
export default {...base,testDir:'/workspace/pdfnova/e2e',outputDir:'/workspace/work/task181/browser-results',retries:0,webServer:undefined,use:{...base.use,launchOptions:{executablePath:'/usr/bin/chromium',args:['--no-sandbox']}}};
